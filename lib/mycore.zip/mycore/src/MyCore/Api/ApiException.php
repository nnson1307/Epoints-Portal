<?php
namespace MyCore\Api;

/**
 * Created by PhpStorm.
 * User: daidp
 * Date: 11/15/2018
 * Time: 11:11 AM
 */
class ApiException extends \Exception
{

}
