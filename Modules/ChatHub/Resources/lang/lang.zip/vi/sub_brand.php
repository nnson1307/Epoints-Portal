<?php

return [
    'index' => [
        'SUB_BRAND'=>'THƯƠNG HIỆU PHỤ',
        'ADD_SUB_BRAND'=>'Thêm thương hiệu phụ',
        'NAME'=>'Tên',
        'ENTITIES'=>'Thực thể',
        'STATUS'=>'Trạng thái',
        'ACTIVE'=>'Hoạt động',
        'UNACTIVE'=>'Không hoạt động',
        'CANCEL'=>'HỦY',
        'SAVE'=>'LƯU',
        'SAVE_NEW'=>'LƯU & TẠO MỚI',
        'EDIT_SUB_BRAND'=>'Sửa thương hiệu phụ',
        'ID'=>'ID',
        'SEARCH'=>'Tìm kiếm',
        'SEARCH_NAME'=>'Tên thương hiệu phụ',
        'SEARCH_ENTITIES'=>'Tên thực thể',
        'SELECT_STATUS'=>'Chọn trạng thái',
        'STATUS'=>'Trạng thái',
        'ACTION'=>''
    ],
    'create' =>[
        'ADD_SUCCESS' =>'Thêm thành công',
        'UPDATE_SUCCESS'=>'Cập nhật thành công',
        'DELETE_SUCCESS'=>'Xóa thành công',
    ]
];
