<?php

return [
    'index' => [
        'ATTRIBUTE'=>'THUỘC TÍNH',
        'ADD_ATTRIBUTE'=>'Thêm thuộc tính',
        'NAME'=>'Tên',
        'ACTIVE'=>'Hoạt động',
        'UNACTIVE'=>'Không hoạt động',
        'CANCEL'=>'HỦY',
        'SAVE'=>'LƯU',
        'SAVE_NEW'=>'LƯU & TẠO MỚI',
        'EDIT_ATTRIBUTE'=>'Sửa thuộc tính',
        'ID'=>'ID',
        'SEARCH'=>'Tìm kiếm',
        'SEARCH_NAME'=>'Tên thuộc tính',
        'SEARCH_ENTITIES'=>'Tên thực thể',
        'SELECT_STATUS'=>'Chọn trạng thái',
        'ENTITIES'=>'Thực thể',
        'STATUS'=>'Trạng thái',
        'ACTION'=>''
    ],
    'create' =>[
        'ADD_SUCCESS' =>'Thêm thành công',
        'UPDATE_SUCCESS'=>'Cập nhật thành công',
        'DELETE_SUCCESS'=>'Xóa thành công',
    ]
];
