<?php

return [
    'index' => [
        'COMMENT'=>'BÌNH LUẬN',
        'SEARCH'=>'Tìm kiếm',
        'ID'=>'ID',
        'MESSAGE_POST'=>'TIN NHẮN BÀI ĐĂNG',
        'SEARCH_NAME'=>'Tìm kiếm',
        'MESSAGE'=>'TIN NHẮN',
        'DATE_COMMENT'=>'NGÀY ĐĂNG',
        'DATE'=>'Ngày bình luận',
        'CHANNEL'=>'KÊNH',
        'POST_ID'=>'ID BÀI ĐĂNG',
        'CUSTOMER_COMMENT'=>'TÊN NGƯỜI BÌNH LUẬN'

    ],
    'update' => [
        'ADD_SUCCESS'=>'Tạo khóa thành công'
    ]
];
