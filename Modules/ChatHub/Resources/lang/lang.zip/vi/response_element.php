<?php

return [
    'index' => [
        
    ],
    'create' =>[
        'ADD_SUCCESS' =>'Thêm thành công',
        'UPDATE_SUCCESS'=>'Cập nhật thành công',
        'DELETE_SUCCESS'=>'Xóa thành công',
    ]
];