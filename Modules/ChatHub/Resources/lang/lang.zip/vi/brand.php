<?php

return [
    'index' => [
        'BRAND'=>'THƯƠNG HIỆU',
        'ADD_BRAND'=>'Thêm thương hiệu',
        'NAME'=>'Tên',
        'ENTITIES'=>'Thực thể',
        'STATUS'=>'Trạng thái',
        'ACTIVE'=>'Hoạt động',
        'UNACTIVE'=>'Không hoạt động',
        'CANCEL'=>'HỦY',
        'SAVE'=>'LƯU',
        'SAVE_NEW'=>'LƯU & TẠO MỚI',
        'EDIT_BRAND'=>'Sửa thương hiệu',
        'ID'=>'ID',
        'SEARCH'=>'Tìm kiếm',
        'SEARCH_NAME'=>'Tên thương hiệu',
        'SEARCH_ENTITIES'=>'Tên thực thể',
        'SELECT_STATUS'=>'Chọn trạng thái',
        'STATUS'=>'Trạng thái',
        'ACTION'=>''
    ],
    'create' =>[
        'ADD_SUCCESS' =>'Thêm thành công',
        'UPDATE_SUCCESS'=>'Cập nhật thành công',
        'DELETE_SUCCESS'=>'Xóa thành công',
    ]
];
