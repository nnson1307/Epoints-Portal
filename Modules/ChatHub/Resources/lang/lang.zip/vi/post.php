<?php

return [
    'index' => [
        'POST'=>'BÀI ĐĂNG',
        'SEARCH'=>'Tìm kiếm',
        'ID'=>'ID',
        'SEARCH_NAME'=>'Tìm kiếm',
        'MESSAGE'=>'TIN NHẮN',
        'BRAND'=>'THƯƠNG HIỆU',
        'SUB_BRAND'=>'THƯƠNG HIỆU PHỤ',
        'SKU'=>'LOẠI SẢN PHẨM',
        'ATTRIBUTE'=>'THUỘC TÍNH',
        'DATE_COMMENT'=>'NGÀY ĐĂNG',
        'DATE'=>'Ngày đăng',
        'CHANNEL'=>'KÊNH',
        'KEY'=>'KHÓA',
        'SUBCRIBE'=>'ĐĂNG KÝ',
        'UNSUBCRIBE'=>'HỦY ĐĂNG KÝ'
    ],
    'update' => [
        'ADD_SUCCESS'=>'Tạo khóa thành công'
    ]
];
