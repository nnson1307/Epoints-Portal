<?php

return [
    'index' => [
        'SKU'=>'LOẠI SẢN PHẨM',
        'ADD_SKU'=>'Thêm loại sản phẩm',
        'NAME'=>'Tên',
        'ENTITIES'=>'Thực thể',
        'STATUS'=>'Trạng thái',
        'ACTIVE'=>'Hoạt động',
        'UNACTIVE'=>'Không hoạt động',
        'CANCEL'=>'HỦY',
        'SAVE'=>'LƯU',
        'SAVE_NEW'=>'LƯU & TẠO MỚI',
        'EDIT_SKU'=>'Sửa loại sản phẩm',
        'ID'=>'ID',
        'SEARCH'=>'Tìm kiếm',
        'SEARCH_NAME'=>'Tên loại sản phẩm',
        'SEARCH_ENTITIES'=>'Tên thực thể',
        'SELECT_STATUS'=>'Chọn trạng thái',
        'STATUS'=>'Trạng thái',
        'ACTION'=>''
    ],
    'create' =>[
        'ADD_SUCCESS' =>'Thêm thành công',
        'UPDATE_SUCCESS'=>'Cập nhật thành công',
        'DELETE_SUCCESS'=>'Xóa thành công',
    ]
];
