<?php

return [
    'index' => [
        'CHATHUB' => 'CÀI ĐẶT',
        'SETTING'=>'Cài đặt',
        'ADD_CHANNEL'=>'Thêm channel',
        'AVATAR'=>'Ảnh',
        'CHANNEL_NAME'=>'Tên channel',
        'LINK_CHANNEL'=>'Đường dẫn channel',
        'MANIPULATION'=>'Thao tác',
        'DIALOGFLOW'=>'Dialogflow',
        'MENU'=>'Cài đặt menu điều hướng',
        'ACTIVE'=>'(Đăng ký channel lại để active)'
    ],
];
