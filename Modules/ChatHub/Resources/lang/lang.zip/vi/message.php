<?php

return [
    'index' =>[
        'SEARCH'=>'Tìm kiếm',
        'DETAIL'=>'Chi tiết',
        'SEND'=>'Gửi',
        'TYPE'=>'Nhập tại đây...',
        'UPLOADIMAGE'=>'Nhấp vào để chọn hình',
        'NOT_EMAIL'=>'Email sai định dạng',
        'UNIQUE_EMAIL'=>'Email đã tồn tại',
        'NOT_PHONE'=>'Số điện thoại phải có 10 số',
        'NUMERIC_PHONE'=>'Số điện thoại phải ở dạng số',
        'UPĐATE_SUCCESS'=>'Cập nhật thành công',
        'IMAGE_SELECT'=>'Chọn hình ảnh',
        'IMAGE_UPLOAD'=>'Tải lên hình ảnh',
        'FILE_SELECT'=>'Chọn tập tin',
        'FILE_UPLOAD'=>'Tải lên tập tin',
        'CANCEL'=>'Hủy',
        'SAVE'=>'Lưu'
    ],
];