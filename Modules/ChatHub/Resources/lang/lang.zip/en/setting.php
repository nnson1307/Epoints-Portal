<?php

return [
    'index' => [
        'CHATHUB' => 'CHATHUB',
        'SETTING'=>'Setting',
        'ADD_CHANNEL'=>'Add channel'
    ],
];